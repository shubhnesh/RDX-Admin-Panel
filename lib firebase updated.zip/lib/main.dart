import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
import 'core/router/app_router.dart';
import 'core/theme/text_styles.dart';
import 'providers/theme_provider.dart';
import 'providers/auth_provider.dart';
import 'providers/dashboard_provider.dart';
import 'providers/live_orders_provider.dart';
import 'providers/menu_provider.dart';
import 'providers/coupon_provider.dart';
import 'providers/notification_provider.dart';
import 'providers/inventory_provider.dart';
import 'providers/settings_provider.dart';
import 'services/dashboard_service.dart';
import 'services/order_service.dart';
import 'services/menu_service.dart';
import 'services/coupon_service.dart';
import 'services/notification_service.dart';
import 'services/inventory_service.dart';
import 'screens/auth/login_screen.dart';
import 'screens/main/main_screen.dart';

/// Set once [main] finishes running. The rest of the app (in particular
/// [AuthProvider]) reads this instead of re-deriving readiness from
/// `Firebase.apps`, so there's a single source of truth for "did Firebase
/// actually come up".
bool firebaseInitError = false;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // firebase_options.dart now points at the real `rdx-restaurant-3ca6c`
  // project (generated via `flutterfire configure`), so this should always
  // succeed on a device/emulator with network access. We still guard it so
  // a genuine outage (no network at cold start, revoked API key, etc.)
  // doesn't crash the whole app before Flutter can even paint a frame —
  // instead we surface a real error banner from [RdxAdminApp] below rather
  // than silently pretending the user is logged in.
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e, st) {
    firebaseInitError = true;
    debugPrint('Firebase failed to initialize: $e');
    if (kDebugMode) debugPrintStack(stackTrace: st);
  }

  if (!firebaseInitError) {
    // Enable offline persistence with an unlimited local cache so the app
    // keeps working (read-only) on a flaky connection and Firestore reads
    // are served from cache instead of round-tripping every time. This is
    // best-effort: some platforms/older plugin versions may not support a
    // given combination of options, and that alone shouldn't take down an
    // otherwise-successful Firebase init.
    try {
      FirebaseFirestore.instance.settings = const Settings(
        persistenceEnabled: true,
        cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
      );
    } catch (e) {
      debugPrint('Firestore persistence not enabled: $e');
    }
  }

  runApp(const RdxAdminApp());
}

class RdxAdminApp extends StatelessWidget {
  const RdxAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => DashboardProvider(DashboardService())),
        ChangeNotifierProvider(create: (_) => LiveOrdersProvider(OrderService())),
        ChangeNotifierProvider(create: (_) => MenuProvider(MenuService())),
        ChangeNotifierProvider(create: (_) => CouponProvider(CouponService())),
        ChangeNotifierProvider(create: (_) => NotificationProvider(NotificationService())),
        ChangeNotifierProvider(create: (_) => InventoryProvider(InventoryService())),
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
      ],
      child: Consumer2<ThemeProvider, AuthProvider>(
        builder: (context, theme, auth, _) {
          return MaterialApp(
            title: 'RDX Admin',
            debugShowCheckedModeBanner: false,
            theme: AppTextStyles.themeData(isDark: false),
            darkTheme: AppTextStyles.themeData(isDark: true),
            themeMode: theme.themeMode,
            home: firebaseInitError
                ? const _FirebaseErrorScreen()
                : (auth.isLoggedIn ? const MainScreen() : const LoginScreen()),
            onGenerateRoute: AppRoutes.generateRoute,
          );
        },
      ),
    );
  }
}

/// Shown instead of silently falling back to mock/offline mode when
/// Firebase genuinely failed to initialize (bad network, revoked key,
/// project deleted, etc.) so the failure is visible instead of hidden
/// behind a login bypass.
class _FirebaseErrorScreen extends StatelessWidget {
  const _FirebaseErrorScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off_rounded, color: Colors.redAccent, size: 40),
              const SizedBox(height: 16),
              const Text(
                "Couldn't connect to Firebase",
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              const Text(
                'Check your network connection and that the rdx-restaurant-3ca6c '
                'Firebase project is reachable, then restart the app.',
                style: TextStyle(color: Color(0xFF9A9494), fontSize: 13),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
