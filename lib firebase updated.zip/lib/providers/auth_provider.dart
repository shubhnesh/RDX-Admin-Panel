import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  /// Firebase is configured against the real `rdx-restaurant-3ca6c` project
  /// (see firebase_options.dart) and `main.dart` refuses to even build this
  /// widget tree if `Firebase.initializeApp` failed — so by the time an
  /// [AuthProvider] exists, Firebase is up. This getter stays as a defensive
  /// guard only (e.g. hot-reload edge cases), never as a "run without auth"
  /// bypass.
  static bool get _firebaseReady => Firebase.apps.isNotEmpty;

  AuthService? _service;
  AuthService? get _safeService {
    if (!_firebaseReady) return null;
    return _service ??= AuthService();
  }

  User? get user => _safeService?.currentUser;

  /// Real auth check — true only when a Firebase user is signed in.
  bool get isLoggedIn => user != null;

  bool isLoading = false;
  String? errorMessage;

  AuthProvider() {
    final service = _safeService;
    if (service != null) {
      service.authStateChanges.listen((_) => notifyListeners());
    }
  }

  Future<bool> signIn(String email, String password) async {
    final service = _safeService;
    if (service == null) {
      errorMessage = 'Unable to reach Firebase right now. Please try again.';
      notifyListeners();
      return false;
    }
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      await service.signIn(email, password);
      isLoading = false;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      errorMessage = e.message ?? 'Login failed';
      isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      errorMessage = e.toString();
      isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> register(String email, String password) async {
    final service = _safeService;
    if (service == null) {
      errorMessage = 'Unable to reach Firebase right now. Please try again.';
      notifyListeners();
      return false;
    }
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      await service.register(email, password);
      isLoading = false;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      errorMessage = e.message ?? 'Registration failed';
      isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      errorMessage = e.toString();
      isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> signOut() async {
    await _safeService?.signOut();
    notifyListeners();
  }
}
