import 'package:cloud_firestore/cloud_firestore.dart';

class ActivityLogModel {
  final String id;
  final String actor;
  final String action;
  final String details;
  final DateTime timestamp;

  ActivityLogModel({
    required this.id,
    required this.actor,
    required this.action,
    required this.details,
    required this.timestamp,
  });

  /// Human-friendly label for the UI — avoids surfacing the raw Firestore
  /// auto-generated document ID. Falls back gracefully if `id` is short
  /// (e.g. the bundled sample activity, which already uses readable IDs
  /// like `ORD-8924`).
  String get displayId {
    if (id.length <= 10) return id; // already short/readable (seed/mock data)
    return id.substring(id.length - 6).toUpperCase();
  }

  factory ActivityLogModel.fromFirestore(DocumentSnapshot doc) {
    final json = doc.data() as Map<String, dynamic>? ?? {};
    return ActivityLogModel.fromJson({...json, 'id': doc.id});
  }

  factory ActivityLogModel.fromJson(Map<String, dynamic> json) {
    return ActivityLogModel(
      id: json['id'] ?? '',
      actor: json['actor'] ?? 'System',
      action: json['action'] ?? '',
      details: json['details'] ?? '',
      timestamp: _parseTimestamp(json['timestamp']) ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'actor': actor,
        'action': action,
        'details': details,
        'timestamp': Timestamp.fromDate(timestamp),
      };

  static DateTime? _parseTimestamp(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}
